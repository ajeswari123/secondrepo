package Operations;

import java.io.IOException;

import java.io.*;
import jakarta.servlet.*;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.*;


/**
 * Servlet implementation class ResultServlet
 */
@WebServlet("/resp")
public class ResultServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;

    /**
     * Default constructor. 
     */
    public ResultServlet() {
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		//response.getWriter().append("Served at: ").append(request.getContextPath());
		
		Integer result=(Integer)request.getAttribute("result");
		RequestDispatcher rd=request.getRequestDispatcher("/user.html");
		if(result==null)
		{
			rd.forward(request,response);
		}
		
		try
		{
			response.setContentType("text/html");
			PrintWriter out=response.getWriter();
			String op=(String)request.getAttribute("operation");
			out.print(op+" "+"Result is:"+result.intValue()+"<br><br>");
			rd.include(request, response);
		}
		catch(Exception e)
		{
		}
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
