package Operations;


import java.io.*;
import jakarta.servlet.*;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.*;
import java.io.IOException;

/**
 * Servlet implementation class CalcServlet
 */
@WebServlet("/calc")
public class CalcServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;

    /**
     * Default constructor. 
     */
    public CalcServlet() {
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		try
		{
			Integer i1=Integer.valueOf(request.getParameter("ip1"));
			Integer i2=Integer.valueOf(request.getParameter("ip2"));
			
			request.setAttribute("n1",i1);
			request.setAttribute("n2",i2);	
		}
		catch(Exception e)
		{
			response.setContentType("text/html");
			PrintWriter out=response.getWriter();
			out.print("Value should be an integer");
			RequestDispatcher rd=request.getRequestDispatcher("/calc");
			rd.include(request,response);
			return;
			
		}
		String action=request.getParameter("action");
		RequestDispatcher rd=null;
		
		if(action.equals("Add"))
				rd=request.getRequestDispatcher("/add");
		else if(action.equals("Subtract"))
			rd=request.getRequestDispatcher("/sub");
		else if(action.equals("Divide"))
			rd=request.getRequestDispatcher("/div");
		else 
			rd=request.getRequestDispatcher("mul");
		rd.forward(request, response);
			
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
