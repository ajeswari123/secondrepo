package Operations;

import java.io.*;
import jakarta.servlet.*;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.*;
import java.io.IOException;


/**
 * Servlet implementation class AddServlet
 */
@WebServlet("/div")
public class DivServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;

    /**
     * Default constructor. 
     */
    public DivServlet() {
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	@SuppressWarnings("removal")
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		//response.getWriter().append("Served at: ").append(request.getContextPath());
		try
		{
		int ip1=((Integer)request.getAttribute("n1")).intValue();
		int ip2=((Integer)request.getAttribute("n2")).intValue();
		int result=ip1/ip2;
		request.setAttribute("operation","Multiplication");
		request.setAttribute("result",new Integer(result));
		RequestDispatcher rd=request.getRequestDispatcher("/resp");
		rd.forward(request, response);	
		}
		catch(Exception e)
		{
			response.setContentType("text/html)");
			PrintWriter out=response.getWriter();
			out.print("Value cannot divide by Zero please enter valid number");
			RequestDispatcher rd=request.getRequestDispatcher("/user.html");
			rd.include(request,response);
			return;
		}
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
